// let a = true;
// let b = false;
//
// if(!a) {
//     console.log('УРААА')
// } else if(!b) {
//     console.log('ываыва')
// }
// else if(!b) {
//     console.log('ываыва')
// }
// else if(!b) {
//     console.log('ываыва')
// }
// else if(!b) {
//     console.log('ываыва')
// }else if(!b) {
//     console.log('ываыва')
// }
// else if(!b) {
//     console.log('ываыва')
// }
//
// //Одинаковый результат, но разная запись
//     if(a) {
//         sum = 123;
//     }
//     else {
//         sum ='kek';
//     }
//
// let sum = a ? 123 : 'kek';
// let sum2 = a ? 123 : b ? 456 : 'test';
//
// console.log(sum)
// console.log(sum2)



//switch { case:... default }

// let test_switch = 5;
//
// switch (test_switch) {
//     case 4: console.log('Никита крутой');
//     case 5: console.log('Никита крутой очень');
//     case 6: console.log('Никита крутой очень');
//     case 7: console.log('Никита крутой очень');
//
//
//     default: console.log('РАБЫНЯ')
// }

//while
//
// let test_while = 5
//
// while(test_while < 10) {
//     test_while++;
//     console.log(test_while)
//     if(test_while === 7) {
//         break;
//     }
// }


//Массивы, split, join - методы массива

// let arr = [1,'dfdf',12312];
// let str = '1,dfdf,12312';
// let str2 = 'привет'
//
// console.log(arr)
// console.log(arr.join())
// console.log(str.split(','))
// console.log(str2.split(''))
//
// console.log(str2.split('').splice(3,2))
//
// //spit - строку в массив
// //join - массив в строку
// //splice - удаление элементов массива

let obj_local = [
    {title: 'НАЗВАНИЕ'},
    {title: 'НАЗВАНИЕ2'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
    {title: 'НАЗВАНИЕ3'},
]

for(let i= 0; i < 10; i++) {
    console.log(obj_local[i].title);
}


//1 урок
//DOM что это?
//Приведение типов ( тема на собесе )
//Область видимости функции ( тема на собесе )
//В чем разниа между let и var



//2 урок - циклы
//Тернарный оператор
//Scope
// замыкания
// function expression и function declaration
//Приведение типов ( тема на собесе )
//Область видимости функции ( тема на собесе )
// Методы массивов learnJs
// что такое JS ( ВИДЕО ) Минин - фамилия ютубера